const accountStorageName = "mywebappbus.accounts";
const loginStorageName = "mywebappbus.currentUser";

function getAccounts() {
    const savedAccounts = localStorage.getItem(accountStorageName);
    return savedAccounts === null ? {} : JSON.parse(savedAccounts);
}

async function makePasswordHash(password, salt) {
    if (!window.crypto || !window.crypto.subtle) {
        throw new Error("กรุณาเปิดเว็บผ่าน localhost หรือ HTTPS เพื่อใช้งานระบบรหัสผ่าน");
    }

    const passwordKey = await crypto.subtle.importKey(
        "raw",
        new TextEncoder().encode(password),
        "PBKDF2",
        false,
        ["deriveBits"]
    );

    const hashBits = await crypto.subtle.deriveBits(
        {
            name: "PBKDF2",
            salt: salt,
            iterations: 120000,
            hash: "SHA-256"
        },
        passwordKey,
        256
    );

    return Array.from(new Uint8Array(hashBits))
        .map(function (number) {
            return number.toString(16).padStart(2, "0");
        })
        .join("");
}

async function saveAccount(account, password) {
    const accounts = getAccounts();
    const usernameKey = account.username.toLowerCase();

    if (accounts[usernameKey]) {
        throw new Error("ชื่อผู้ใช้นี้มีคนใช้แล้ว");
    }

    const salt = crypto.getRandomValues(new Uint8Array(16));
    const saltText = Array.from(salt)
        .map(function (number) {
            return number.toString(16).padStart(2, "0");
        })
        .join("");

    account.salt = saltText;
    account.passwordHash = await makePasswordHash(password, salt);
    accounts[usernameKey] = account;
    localStorage.setItem(accountStorageName, JSON.stringify(accounts));
}

async function checkLogin(username, password) {
    const accounts = getAccounts();
    const account = accounts[username.trim().toLowerCase()];

    if (!account) {
        return null;
    }

    const saltBytes = account.salt.match(/.{2}/g).map(function (byte) {
        return parseInt(byte, 16);
    });
    const passwordHash = await makePasswordHash(
        password,
        new Uint8Array(saltBytes)
    );

    return passwordHash === account.passwordHash ? account : null;
}

function saveLogin(username) {
    sessionStorage.setItem(loginStorageName, username);
}

function logout() {
    sessionStorage.removeItem(loginStorageName);
}
